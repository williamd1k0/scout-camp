var scoutboard = document.querySelector('#scout-board');
scoutboard.innerHTML = `
    William Tuméo
    Lucas Flicky
`;

var dump = [
        {
            "nome":"William Tuméo",
            "id":"williamd1k0",
            "faceid":"100001156867316",
            "badges": ['mythDiamond', 'merito', 'programeiro']
        },
        {
            "nome":"Lucas Flicky",
            "id":"lucasflicky",
            "faceid":"1489576273",
            "badges": ['mythMinister', 'desenheiro', 'programeiro']
        },
];
